import React, {useEffect, useState} from 'react';
import { Link, navigate } from '@reach/router';
import axios from 'axios';
import NewPet from './NewPet';
import Header from './Header';



const EditPet = (props) => {

    const {id} = props;
    const[errors, setErrors]= useState({});
    const [updatingPetName, setUpdatingPetName] = useState({});
    const [updatingPetType, setUpdatingPetType] = useState({});
    const [updatingPetDescription, setUpdatingPetDescription] = useState({});
    const [skill1, setSkill1] = useState({});
    const [skill2, setSkill2] = useState({});
    const [skill3, setSkill3] = useState({});
    useEffect(()=>{
        axios.get(`http://localhost:8000/api/pets/${id}`)
            .then((response)=>{
                console.log(response.data);
                setUpdatingPetName(response.data);
                setUpdatingPetType(response.data);
                setUpdatingPetDescription(response.data);
                setSkill1(response.data);
                setSkill2(response.data);
                setSkill3(response.data);
            })
            .catch((err)=>{
                console.log(err);
                navigate('/error');
            })
    },[id])
    
    const onChangeHandler= (e) => {
        let newStateObject = {...updatingPetName, updatingPetType, updatingPetDescription};
        newStateObject[e.target.name]= e.target.value;
        newStateObject[e.target.type]= e.target.value;
        newStateObject[e.target.description]= e.target.value;
        setUpdatingPetName(newStateObject);
        setUpdatingPetType(newStateObject);
        setUpdatingPetDescription(newStateObject);
    }

    const onSubmitHandler = (e)=> {
        e.preventDefault();
        axios.put(`http://localhost:8000/api/pets/${id}`,
        updatingPetName,
        updatingPetType,
        updatingPetDescription
        )
        .then((response)=>{
            console.log(response.data);
            navigate("/");
        })
        .catch((err)=>{
            console.log(err);
            setErrors(err.response.data.errors);
        })
    }

    return(
        <div>
            <Header link={'/'} linkText="back to home" subText="Edit Pet"/>
            <form style={{margin:'auto', border:"1px solid black"}} onSubmit={onSubmitHandler}>
                <label>Name:</label>
                <input onChange={onChangeHandler} name="name" value={updatingPetName.name}/><br />
                {
                    errors.name?
                    <span>{errors.name.message}</span>
                    :null
                }
                <label>Type:</label>
                <input onChange={onChangeHandler} name="type" value={updatingPetType.type}/><br />
                {
                    errors.type?
                    <span>{errors.type.message}</span>
                    :null
                }
                <label>Description:</label>
                <input onChange={onChangeHandler} name="description" value={updatingPetDescription.description}/><br />
                {
                    errors.description?
                    <span>{errors.description.message}</span>
                    :null
                }
                                <p>Skills(optional):</p>
                <p>Skill 1: <input type="text" onChange={e => setSkill1(e.target.value)} ></input></p>
                <p>Skill 2: <input type="text" onChange={e => setSkill2(e.target.value)} ></input></p>
                <p>Skill 3: <input type="text" onChange={e => setSkill3(e.target.value)} ></input></p>
                <button style={{backgroundColor:"#0066ff", color:"white"}}>Edit Pet</button>
            </form>
        </div>
    )
}

export default EditPet;


//