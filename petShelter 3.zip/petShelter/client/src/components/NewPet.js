import React, {useState} from 'react';
import { navigate } from '@reach/router';
import axios from 'axios';
import Header from './Header';

const NewPet = (props) => {
    const[errors, setErrors]= useState({});
    const [newPetName, setNewPetName] = useState({});
    const [newPetType, setNewPetType] = useState({});
    const [newPetDescription, setNewPetDescription] = useState({});
    const [skill1, setSkill1] = useState("");
    const [skill2, setSkill2] = useState("");
    const [skill3, setSkill3] = useState("");

    const onChangeHandler= (e) => {
        let newStateObject = {...newPetName, newPetType, newPetDescription};
        const elementName = e.target.name;
        if (elementName === "name" ) {
            newStateObject={...newPetName};
            newStateObject["name"]= e.target.value;
            setNewPetName(newStateObject);
        } else if (elementName === "type") {
            newStateObject={...newPetType};
            newStateObject["type"]= e.target.value;
            setNewPetType(newStateObject);
        } else if (elementName === "description") {
            newStateObject={...newPetDescription};
            newStateObject["description"]= e.target.value;
            setNewPetDescription(newStateObject);
        }

        // newStateObject[e.target.skill1]= e.target.value;
        // newStateObject[e.target.skill2]= e.target.value;
        // newStateObject[e.target.skill3]= e.target.value;
        // setSkill1(newStateObject);
        // setSkill2(newStateObject);
        // setSkill3(newStateObject);
    }

    const newSubmitHandler = (e)=> {
        e.preventDefault();
        debugger;
        axios.post("http://localhost:8000/api/pets",{
        name: newPetName.name,
        type:newPetType.type,
        description:newPetDescription.description,
        skill1,
        skill2,
        skill3
        }, [])
        .then((response)=>{
            console.log(response.data);
            navigate("/");
        })
        .catch((err)=>{
            console.log(err);
            setErrors(err.response.data.errors);
        })
    }

    return(
        <div>
            <Header link={'/'} linkText="back to home" subText="Know a pet needing a home?"/>
            <fieldset>
            <form onSubmit={newSubmitHandler}>
                <p>Pet Name:
                <input onChange={onChangeHandler} name="name" value={newPetName.name}/><br />
                {
                    errors.name?
                    <span>{errors.name.message}</span>
                    :null
                }
                </p> 
                <p>Pet Type:
                <input onChange={onChangeHandler} name="type" value={newPetType.type}/><br />
                {
                    errors.type?
                    <span>{errors.type.message}</span>
                    :null
                }
                </p> 
                <p>Description:
                <input onChange={onChangeHandler} name="description" value={newPetDescription.description}/><br />
                {
                    errors.description?
                    <span>{errors.description.message}</span>
                    :null
                }
                </p> 
                <p>Skills(optional):</p>
                <p>Skill 1: <input type="text" onChange={e => setSkill1(e.target.value)} ></input></p>
                <p>Skill 2: <input type="text" onChange={e => setSkill2(e.target.value)} ></input></p>
                <p>Skill 3: <input type="text" onChange={e => setSkill3(e.target.value)} ></input></p>
                <button style={{backgroundColor:"#0066ff", color:"white"}}>Add Pet</button>
            </form>
            </fieldset>
        </div>
    )
}

export default NewPet;

//