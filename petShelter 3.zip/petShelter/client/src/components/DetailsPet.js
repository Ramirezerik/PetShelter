import React, {useEffect, useState} from 'react';
import axios from 'axios';
import Header from './Header';

const PetDetails = (props) => {
    const {id} = props;
    const [pets, setPets] = useState([]);
    const [pet, setPet]= useState({});

    useEffect(()=> {
        axios.get(`http://localhost:8000/api/pets/${id}`)
            .then((response)=>{
                console.log(response);
                console.log(response.data);
                setPets(response.data);
            })
            .catch((err)=>{
                console.log(err)
            })
    }, [id])

    const deleteHandler = (id)=> {
        axios.delete(`http://localhost:8000/api/pets/${id}`)
            .then((response)=>{
                console.log(response);
                setPet(pet.filter((pet)=>pet._id !== id))
            })
            .catch((err)=>{
                console.log(err)
            })
    }

    return(
        <div>
            <Header link={'/'} linkText="back to home" subText="Details about " />
                <h3>{pets.name}</h3>
            <fieldset>
                <h3>Pet Type: {pets.type}</h3>
                <h3>Pet Description: {pets.description}</h3>
                <h3>Skills (optional)</h3>
                    <li>{pets.skill1}</li>
                    <li>{pets.skill2}</li>
                    <li>{pets.skill3}</li>

                <button onClick={(e)=> deleteHandler(pets.id)} style={{backgroundColor:"red", color:"white"}}>Adopt Pet</button>
            </fieldset>
        </div>
    )
}


export default PetDetails;

